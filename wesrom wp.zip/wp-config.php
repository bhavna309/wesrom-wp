<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wesrom' );

/** Database username */
define( 'DB_USER', 'wesrom' );

/** Database password */
define( 'DB_PASSWORD', 'admin@?123' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ':9qbUwm@F}cfu*[NL~/?~*6yTaj(&/#OZTl?kCzNbo^l`XSR1Ph+H/s4C$S,x_Tl' );
define( 'SECURE_AUTH_KEY',  '-@Ug[g|V&w#|WMur=mP[X.4FSpf%Z5PP&7xl6`:-e`10N{N &W=/6ZUbdK%,9k[N' );
define( 'LOGGED_IN_KEY',    ',+dVI><!781SEjj2_nUt(`qxRd6RYP% km|i8l, Pm/=uX#1b&oq)lowCYA<:$v:' );
define( 'NONCE_KEY',        'MJRw_jQE:Y=H,C|_Q-8P5^/ik>v2_h?G=Dl(QA6Ab`Jz)Jp&!CrHJ0`SF^P;35^#' );
define( 'AUTH_SALT',        'DXvW]C[MPEv<iDrQo-a*.iDA8tf^n]*^SUU4}go6^fE4N?M6~IrULZ!45n$1KGJO' );
define( 'SECURE_AUTH_SALT', '+WcnysD0_jl0QOVAO@G3.)m&4N~*0GJ<Z9u?t|_RA~KGrg>219+[0.VB1I^* -id' );
define( 'LOGGED_IN_SALT',   '_sNHv1|Nxx#06<<H+AW5X+7#Db-y]4q;QSF|[?)w >Baj~dHngn/l<a;)wyetk?Z' );
define( 'NONCE_SALT',       'J6`XAb&n#YoI#REsT69O) WM$X4zC)z5fL;_D,K:mhji[MY=0ROp8oe)g6t@Pz8U' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
